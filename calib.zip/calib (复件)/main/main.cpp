#include "calib/params_init.h"
#include "calib/calib.h"
#include <iostream>
#include <vector>
#include <string>



int main()
{
    INIT init;
    /*1 参数初始化*/
    std::string configFile = "/home/minieye/桌面/calib/parameter/params.txt" ;
    init.params_init(configFile);
    std::cout << "参数配置文件输入完成！" << std::endl;

    /*2 载入标定用图片*/
    std::vector<std::string> img_files;
    init.GetFile(init.srcImg_path, img_files);
    std::cout << "载入标定用图片:" << img_files.size() << std::endl;
    // for(int i = 0; i < (int)img_files.size(); i++){ //验证文件顺序是否正确
    //    std::cout << img_files[i] << std::endl;
    // }

     /*3 载入标定用点云数据*/
    std::vector<std::string> csv_files;
    init.GetFile(init.srclidarPoints_path, csv_files);
    std::cout << "载入标定用点云数据:" << csv_files.size() << std::endl;
    // for(int i = 0; i < (int)csv_files.size(); i++){ //验证文件顺序是否正确
    //    std::cout << csv_files[i] << std::endl;
    // }
     /*4 图像 点云数据匹配*/
    init.FileMatch(init.log_txt_path, img_files, csv_files);

    CALIB calib;
   /* 5 循环读取图像和点云数据，并提取对应特征 */
    int success_(0), fail_(0); //用来记录图像和激光点云对应特征提取成功的帧数
    for(int i = 0; i < (int)img_files.size(); i++){
        /* 读取图像文件 */
        cv::Mat img = calib.ReadImg(img_files[i], init.srcImg_path);
        // /* 读取csv文件 */
        pcl::PointCloud<PointXYZIR>::Ptr laserCloudIn = calib.ReadCsv(init.srclidarPoints_path, init.need_csv_files[i]) ;
       
        /* 特征(映射点)提取 */
        calib.GetImgFeature(img, init.grid_size, init.square_length, init.board_dimension, init.cameramat, init.distcoeff);

        if(calib.GetLidarFeature(laserCloudIn, init.x_range_point_filter, init.y_range_point_filter, init.z_range_point_filter, init.plane_line_dist_threshold, init.lidar_ring_count, init.line_fit2real_dist))
        {
            std::cout << img_files[i] << "和" << csv_files[i] << "对应特征提取成功！" << std::endl;
        };



   }














    


}



